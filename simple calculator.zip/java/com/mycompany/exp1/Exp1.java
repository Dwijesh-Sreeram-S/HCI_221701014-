/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exp1;

/**
 *
 * @author student1
 */
public class Exp1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
